document.addEventListener('DOMContentLoaded', () => {
  const boardElement = document.getElementById('board');
  const cells = document.querySelectorAll('.cell');
  const restartButton = document.getElementById('restart');
  const statusDisplay = document.getElementById('status');
  const friendModeButton = document.getElementById('friend-mode');
  const aiModeButton = document.getElementById('ai-mode');
  const markerXButton = document.getElementById('marker-x');
  const markerOButton = document.getElementById('marker-o');

  let board = ['', '', '', '', '', '', '', '', ''];
  let currentPlayer = 'X';
  let playerMarker = 'X';
  let aiMarker = 'O';
  let gameActive = false;
  let singlePlayer = false;

  const winningConditions = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
  ];

  function handleModeSelection(mode) {
    singlePlayer = mode === 'ai';
    statusDisplay.textContent = 'Choose your marker!';
    friendModeButton.classList.toggle('selected', mode === 'friend');
    aiModeButton.classList.toggle('selected', mode === 'ai');
    gameActive = false;  
  }

  function handleMarkerSelection(marker) {
    playerMarker = marker;
    aiMarker = marker === 'X' ? 'O' : 'X';
    currentPlayer = playerMarker;
    statusDisplay.textContent = `${currentPlayer}'s turn`;
    markerXButton.classList.toggle('selected', marker === 'X');
    markerOButton.classList.toggle('selected', marker === 'O');
    gameActive = true;
    if (singlePlayer && currentPlayer === aiMarker) aiMove();
  }

  function handleCellClick(cell, index) {
    if (board[index] !== '' || !gameActive) return;
    board[index] = currentPlayer;
    cell.textContent = currentPlayer;
    cell.style.color = currentPlayer === 'X' ? '#1892EA' : '#A737FF';
    checkResult();
    if (gameActive) {
      currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
      statusDisplay.textContent = `${currentPlayer}'s turn`;

      if (singlePlayer && currentPlayer === aiMarker) {
        setTimeout(aiMove, 500);
      }
    }
  }

  function aiMove() {
    let availableSpots = board.map((value, index) => (value === '' ? index : null)).filter(v => v !== null);
    let aiChoice = availableSpots[Math.floor(Math.random() * availableSpots.length)];
    board[aiChoice] = aiMarker;
    cells[aiChoice].textContent = aiMarker;
    cells[aiChoice].style.color = aiMarker === 'X' ? '#1892EA' : '#A737FF';
    checkResult();
    if (gameActive) {
      currentPlayer = playerMarker;
      statusDisplay.textContent = `${currentPlayer}'s turn`;
    }
  }

  function checkResult() {
    let roundWon = winningConditions.some(condition => {
      return board[condition[0]] && board[condition[0]] === board[condition[1]] && board[condition[0]] === board[condition[2]];
    });

    if (roundWon) {
      statusDisplay.textContent = `${currentPlayer} wins!`;
      gameActive = false;
      return;
    }

    if (!board.includes('')) {
      statusDisplay.textContent = 'It\'s a draw!';
      gameActive = false;
    }
  }

  function restartGame() {
    board = ['', '', '', '', '', '', '', '', ''];
    cells.forEach(cell => cell.textContent = '');
    gameActive = false;
    statusDisplay.textContent = 'Select Game Mode:';
    currentPlayer = playerMarker;
    friendModeButton.classList.remove('selected');
    aiModeButton.classList.remove('selected');
    markerXButton.classList.remove('selected');
    markerOButton.classList.remove('selected');
  }

  friendModeButton.addEventListener('click', () => handleModeSelection('friend'));
  aiModeButton.addEventListener('click', () => handleModeSelection('ai'));
  markerXButton.addEventListener('click', () => handleMarkerSelection('X'));
  markerOButton.addEventListener('click', () => handleMarkerSelection('O'));
  restartButton.addEventListener('click', restartGame);

  cells.forEach((cell, index) => {
    cell.addEventListener('click', () => handleCellClick(cell, index));
  });
});
